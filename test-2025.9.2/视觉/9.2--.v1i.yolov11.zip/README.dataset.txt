# 9.2测试 > 2025-09-02 6:34pm
https://universe.roboflow.com/2787888511-qq-com/9.2-5ub3q

Provided by a Roboflow user
License: CC BY 4.0

